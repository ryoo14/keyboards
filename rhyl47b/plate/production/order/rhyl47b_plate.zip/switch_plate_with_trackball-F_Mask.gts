G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-04-24T19:54:50+09:00*
G04 #@! TF.ProjectId,switch_plate_with_trackball,73776974-6368-45f7-906c-6174655f7769,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-04-24 19:54:50*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
